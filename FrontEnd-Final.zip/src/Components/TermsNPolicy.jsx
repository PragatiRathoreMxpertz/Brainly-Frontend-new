import React from 'react'

function TermsNPolicy() {
  return (
    <div>TermsNPolicy</div>
  )
}

export default TermsNPolicy